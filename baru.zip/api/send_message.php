<?php
header('Content-Type: application/json');
session_start();

if (!isset($_SESSION['agent_id'])) {
    echo json_encode(['status' => 'error', 'message' => 'Unauthorized']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $chat_id    = $_POST['chat_id'] ?? '';
    $number     = $_POST['number'] ?? '';
    $message    = trim($_POST['message'] ?? '');
    $file_url   = $_POST['file_url'] ?? null;

    if (empty($chat_id) || empty($number) || empty($message)) {
        echo json_encode(['status' => 'error', 'message' => 'Field tidak lengkap']);
        exit;
    }

    if (strlen($message) > 65535) {
        echo json_encode(['status' => 'error', 'message' => 'Pesan terlalu panjang']);
        exit;
    }

    require_once __DIR__ . '/../database.php';
    $pdo = (new Database())->getConnection();

    require_once __DIR__ . '/../api_whacenter.php';
    $api = new WhacenterAPI();

    if ($file_url) {
        $result = $api->sendMessage($number, '📎 *File/Image*', $file_url);
        if (!$result['success']) {
            echo json_encode(['status' => 'error', 'message' => 'Gagal kirim file: ' . $result['error']]);
            exit;
        }
    }

    $result = $api->sendMessage($number, $message);
    
    if ($result['success']) {
        $whacenter_id = $result['data']['id'] ?? null;

        $stmt = $pdo->prepare("
            INSERT INTO messages (chat_id, sender_type, pesan, tipe_pesan, is_wa_sent, whacenter_msg_id)
            VALUES (:chat_id, 'agent', :pesan, :tipe, 1, :wc_id)
        ");
        $stmt->execute([
            'chat_id' => $chat_id,
            'pesan'   => $message,
            'tipe'    => $file_url ? 'file' : 'text',
            'wc_id'   => $whacenter_id,
        ]);

        $pdo->prepare('UPDATE chats SET assigned_at = NOW() WHERE id = :id')
            ->execute(['id' => $chat_id]);

        echo json_encode([
            'status'    => 'success',
            'message'   => 'Pesan terkirim',
            'msg_id'    => $pdo->lastInsertId(),
            'created_at' => date('Y-m-d H:i:s'),
            'is_wa_sent' => 1,
        ]);
        exit;
    }

    echo json_encode(['status' => 'error', 'message' => 'Gagal kirim ke WA: ' . $result['error']]);
    exit;
}

echo json_encode(['status' => 'error', 'message' => 'Method tidak diizinkan']);
